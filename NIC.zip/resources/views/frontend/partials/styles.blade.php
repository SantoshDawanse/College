<!-- All PLUGINS CSS ============================================= -->
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/assets.css') }}">

<!-- TYPOGRAPHY ============================================= -->
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/typography.css') }}">

<!-- SHORTCODES ============================================= -->
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/shortcodes/shortcodes.css') }}">

<!-- STYLESHEETS ============================================= -->
<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style.css') }}">
<link class="skin" rel="stylesheet" type="text/css" href="{{ asset('assets/css/color/color-1.css') }}">

<!-- REVOLUTION SLIDER CSS ============================================= -->
<link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/revolution/css/layers.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/revolution/css/settings.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('assets/vendors/revolution/css/navigation.css') }}">
<!-- REVOLUTION SLIDER END -->