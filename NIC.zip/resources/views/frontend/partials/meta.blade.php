<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="" />
<meta name="author" content="" />
<meta name="robots" content="" />

<!-- DESCRIPTION -->
<meta name="description" content="National Integrated College" />

<!-- OG -->
<meta property="og:title" content="National Integrated College" />
<meta property="og:description" content="BHM, BCA, BSW, BBS, +2 Science, Management and Humanities" />
<meta property="og:image" content="" />
<meta name="format-detection" content="telephone=no">

<!-- FAVICONS ICON ============================================= -->
<link rel="icon" href="{{ asset('assets/images/favicon.ico') }}" type="image/x-icon" />
<link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets/images/favicon.png') }}" />